export const API_URL = "https://forkify-api.herokuapp.com/api/v2/recipes/";
export const time_out = 10;
export const Res_Per_Page = 10;
export const key = "8e015f87-d435-4f94-821b-c9a5ebbd1e68";
export const model_time_out = 5;
